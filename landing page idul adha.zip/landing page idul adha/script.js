document.getElementById("greetingBtn").addEventListener("click", function() {
  alert("Taqabbalallahu minna wa minkum!");
});
